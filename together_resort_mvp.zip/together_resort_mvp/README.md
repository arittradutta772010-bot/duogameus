# TOGETHER — Private Multiplayer Resort MVP

A small browser-based 3D multiplayer hangout prototype. Two people can join the same room code, see each other's avatars move, wave, sit/stand, and chat.

## Requirements
- Node.js 18 or newer
- Internet connection (Three.js and Google Fonts are loaded from CDNs)

## Run locally
1. Extract the ZIP.
2. Open a terminal in this folder.
3. Run `npm install`.
4. Run `npm start`.
5. Open `http://localhost:3000`.
6. Open the same URL in another browser/device on the same network, or deploy the app to a public Node.js host.
7. Enter the same room code on both devices. Use different display names.

## Deploying
This is a Node.js + Socket.IO app, so it needs a host that supports a persistent Node server and WebSockets. A static-only Vercel Drop upload will not run the multiplayer server. Deploy the whole project to a Node-compatible host (for example, Render, Railway, or a VPS), set the start command to `npm start`, and use the generated public URL.

## Current MVP limitations
- The room is limited to two players.
- The resort is built from procedural 3D geometry; it is a prototype environment, not photorealistic art.
- Avatars are simple placeholder characters.
- Voice chat, accounts, saved rooms, and custom 3D assets are not included yet.
- For production, add authentication, server-side input validation/rate limits, HTTPS, moderation, and stronger reconnection handling.

## Controls
- WASD or arrow keys: move
- Drag mouse: look around
- E: wave
- Q: sit/stand
- Chat panel: send text messages
