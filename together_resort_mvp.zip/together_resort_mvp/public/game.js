import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js";

const $ = (id) => document.getElementById(id);
const socket = io();
let scene, camera, renderer, clock, selfId, roomCode;
let players = new Map();
let keys = {};
let yaw = 0, pitch = -0.12, dragging = false, lastX = 0, lastY = 0;
let localAction = "idle", actionUntil = 0, lastSend = 0;
let sitting = false;
const playerSpeed = 5.2;

function makeMaterial(color, roughness=0.8, metalness=0) {
  return new THREE.MeshStandardMaterial({ color, roughness, metalness });
}
function addBox(parent, name, x,y,z, sx,sy,sz, material) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(sx,sy,sz), material);
  mesh.name=name; mesh.position.set(x,y,z); mesh.castShadow=true; mesh.receiveShadow=true; parent.add(mesh); return mesh;
}
function buildResort() {
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x9bb9b9);
  scene.fog = new THREE.Fog(0x9bb9b9, 28, 75);
  camera = new THREE.PerspectiveCamera(65, innerWidth/innerHeight, .1, 120);
  camera.position.set(0, 2.7, 8);
  renderer = new THREE.WebGLRenderer({ antialias:true, powerPreference:"high-performance" });
  renderer.setSize(innerWidth, innerHeight);
  renderer.setPixelRatio(Math.min(devicePixelRatio, 1.7));
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.12;
  document.body.appendChild(renderer.domElement);

  scene.add(new THREE.HemisphereLight(0xc9e7e5,0x53483b,2.0));
  const sun = new THREE.DirectionalLight(0xffd7a0,3.1);
  sun.position.set(-8,14,7); sun.castShadow=true; sun.shadow.mapSize.set(2048,2048); scene.add(sun);

  const floorMat=makeMaterial(0x9a8066), wallMat=makeMaterial(0xe7dfd0), dark=makeMaterial(0x263a3b), glass=new THREE.MeshPhysicalMaterial({color:0xa7d1d2,transparent:true,opacity:.19,roughness:.08,metalness:.1});
  addBox(scene,"floor",0,-.15,0,22,.3,20,floorMat);
  addBox(scene,"back wall",0,3,-9.8,22,6,.25,wallMat);
  addBox(scene,"left wall",-10.9,3,0,.25,6,20,wallMat);
  addBox(scene,"right wall",10.9,3,0,.25,6,20,wallMat);
  addBox(scene,"ceiling",0,6,0,22,.2,20,dark);
  // Panoramic ocean-facing glass and ocean beyond
  addBox(scene,"glass window",0,3,9.72,21,5.7,.08,glass);
  const oceanMat = new THREE.MeshStandardMaterial({color:0x2e7f88,roughness:.28,metalness:.12});
  addBox(scene,"ocean",0,-1.5,25,100,.2,45,oceanMat);
  const balconyMat=makeMaterial(0xddd5c5);
  addBox(scene,"balcony",0,-.02,13.3,19,.18,6,balconyMat);
  addBox(scene,"balcony rail",0,.65,16.2,19,.12,.12,makeMaterial(0xe8e5dc));
  addBox(scene,"balcony rail left",-9.4,.65,13.2,.12,.12,6,makeMaterial(0xe8e5dc));
  addBox(scene,"balcony rail right",9.4,.65,13.2,.12,.12,6,makeMaterial(0xe8e5dc));
  // Bed
  addBox(scene,"bed base",-5,.35,-4.4,5.2,.7,3.8,makeMaterial(0x493d37));
  addBox(scene,"mattress",-5,.78,-4.4,5.05,.22,3.7,makeMaterial(0xf0e9db));
  addBox(scene,"headboard",-5,1.5,-6.25,5.2,1.6,.25,makeMaterial(0x59483c));
  for(let i=0;i<2;i++) addBox(scene,"pillow",-6.2+i*2.3,1.0,-5.65,1.7,.25,1.1,makeMaterial(0xffffff));
  // Sofa and coffee table
  addBox(scene,"sofa",-1.4,.55,2.3,4.2,.8,1.3,makeMaterial(0x526b65));
  addBox(scene,"sofa back",-1.4,1.2,1.7,4.2,1.2,.35,makeMaterial(0x526b65));
  addBox(scene,"coffee table",-1.4,.45,4.4,2.7,.18,1.3,makeMaterial(0x6c4d35));
  // Rug and lamps
  addBox(scene,"rug",-1.4,.02,3.4,6,.06,4.2,makeMaterial(0xc7ad83));
  const lamp = new THREE.PointLight(0xffc98c,25,13); lamp.position.set(7,4,-3); scene.add(lamp);
  addBox(scene,"cabinet",7,.7,-5,2.1,1.4,1,makeMaterial(0x735b45));
  // Plants
  for(const [x,z] of [[8,5],[-8,5],[8,-7],[-9,-7]]) {
    const pot=new THREE.Mesh(new THREE.CylinderGeometry(.35,.45,.7,12),makeMaterial(0x8d6248)); pot.position.set(x,.35,z); scene.add(pot);
    for(let j=0;j<5;j++){
      const leaf=new THREE.Mesh(new THREE.ConeGeometry(.22,1.7,7),makeMaterial(0x426d52));
      leaf.position.set(x+(Math.random()-.5)*.5,1.45,z+(Math.random()-.5)*.5); leaf.rotation.z=(Math.random()-.5)*.7; scene.add(leaf);
    }
  }
  // Ceiling lights
  for(let x=-7;x<=7;x+=7) {
    const light=new THREE.PointLight(0xffe0b5,9,9); light.position.set(x,5.5,-1); scene.add(light);
    const bulb=new THREE.Mesh(new THREE.SphereGeometry(.09,12,8),makeMaterial(0xffe2b4,0.3)); bulb.position.copy(light.position); scene.add(bulb);
  }
  // Distant island silhouettes
  for(let i=0;i<8;i++){
    const island=new THREE.Mesh(new THREE.ConeGeometry(2+Math.random()*2,3+Math.random()*3,7),makeMaterial(0x476d66));
    island.position.set(-25+i*7,1,35+Math.random()*8); scene.add(island);
  }
  clock = new THREE.Clock();
  window.addEventListener("resize", onResize);
  renderer.domElement.addEventListener("pointerdown", e=>{dragging=true;lastX=e.clientX;lastY=e.clientY;renderer.domElement.setPointerCapture(e.pointerId);});
  renderer.domElement.addEventListener("pointerup",()=>dragging=false);
  renderer.domElement.addEventListener("pointermove", e=>{
    if(!dragging)return;
    yaw -= (e.clientX-lastX)*.004;
    pitch = Math.max(-.65,Math.min(.35,pitch-(e.clientY-lastY)*.003));
    lastX=e.clientX;lastY=e.clientY;
  });
  animate();
}
function makeAvatar(name, id) {
  const group=new THREE.Group();
  const shirt=makeMaterial(id===selfId?0xb68c59:0x527c82);
  const skin=makeMaterial(0xc99370);
  const pants=makeMaterial(0x26323a);
  const body=new THREE.Mesh(new THREE.CapsuleGeometry(.34,.75,5,10),shirt); body.position.y=1.12; body.castShadow=true; group.add(body);
  const head=new THREE.Mesh(new THREE.SphereGeometry(.27,16,12),skin); head.position.y=1.86; head.castShadow=true; group.add(head);
  for(const x of [-.17,.17]){
    const leg=new THREE.Mesh(new THREE.CapsuleGeometry(.12,.58,4,8),pants); leg.position.set(x,.42,0); group.add(leg);
  }
  const labelCanvas=document.createElement("canvas"); labelCanvas.width=512; labelCanvas.height=128;
  const ctx=labelCanvas.getContext("2d"); ctx.fillStyle="#ffffff";ctx.font="bold 42px Arial";ctx.textAlign="center";ctx.fillText(name.slice(0,18),256,75);
  const tex=new THREE.CanvasTexture(labelCanvas);
  const label=new THREE.Sprite(new THREE.SpriteMaterial({map:tex,transparent:true,depthTest:false}));
  label.scale.set(2.2,.55,1); label.position.y=2.55; group.add(label);
  scene.add(group);
  return {group, name, action:"idle", target:new THREE.Vector3(), rotation:0, phase:Math.random()*6};
}
function addOrUpdatePlayer(p) {
  let item=players.get(p.id);
  if(!item){item=makeAvatar(p.name,p.id);players.set(p.id,item);}
  item.target.set(p.x,p.y,p.z); item.rotation=p.rotation; item.action=p.action;
}
function removePlayer(id) { const p=players.get(id); if(p){scene.remove(p.group);players.delete(id);} }
function onResize(){ if(!camera||!renderer)return;camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight); }
function animate(){
  requestAnimationFrame(animate);
  if(!renderer)return;
  const dt=Math.min(clock.getDelta(),.05);
  const me=players.get(selfId);
  if(me){
    const forward=new THREE.Vector3(-Math.sin(yaw),0,-Math.cos(yaw));
    const right=new THREE.Vector3(Math.cos(yaw),0,-Math.sin(yaw));
    let move=new THREE.Vector3();
    if(keys.KeyW||keys.ArrowUp)move.add(forward);
    if(keys.KeyS||keys.ArrowDown)move.sub(forward);
    if(keys.KeyD||keys.ArrowRight)move.add(right);
    if(keys.KeyA||keys.ArrowLeft)move.sub(right);
    if(move.lengthSq()>0 && !sitting){
      move.normalize().multiplyScalar(playerSpeed*dt);
      me.group.position.add(move);
      me.group.position.x=THREE.MathUtils.clamp(me.group.position.x,-9.5,9.5);
      me.group.position.z=THREE.MathUtils.clamp(me.group.position.z,-8.5,15.5);
      me.group.rotation.y=Math.atan2(move.x,move.z);
      me.action="walk";
    } else if(localAction==="wave" && performance.now()<actionUntil){me.action="wave";}
    else if(sitting){me.action="sit";}
    else {me.action="idle";}
    if(performance.now()>actionUntil && localAction==="wave")localAction="idle";
    const targetCam=new THREE.Vector3(me.group.position.x+Math.sin(yaw)*7,2.8+pitch*3,me.group.position.z+Math.cos(yaw)*7);
    camera.position.lerp(targetCam,1-Math.pow(.001,dt));
    camera.lookAt(me.group.position.x,1.15,me.group.position.z);
    const now=performance.now();
    if(now-lastSend>50){
      socket.emit("player-update",{x:me.group.position.x,y:0,z:me.group.position.z,rotation:me.group.rotation.y,action:me.action});
      lastSend=now;
    }
  }
  for(const [id,p] of players){
    if(id===selfId)continue;
    p.group.position.lerp(p.target,Math.min(1,dt*12));
    p.group.rotation.y=THREE.MathUtils.lerp(p.group.rotation.y,p.rotation,Math.min(1,dt*10));
    const body=p.group.children[0];
    if(p.action==="wave"){body.rotation.z=Math.sin(performance.now()*.012)*.2;}
    else body.rotation.z=0;
  }
  renderer.render(scene,camera);
}
function showChat(name,text){const line=document.createElement("div");line.className="chat-line";const b=document.createElement("b");b.textContent=name+": ";line.append(b,document.createTextNode(text));$("chat-log").append(line);$("chat-log").scrollTop=$("chat-log").scrollHeight;}
function enterGame(data){
  selfId=data.selfId;roomCode=data.roomCode;
  $("room-label").textContent=roomCode;
  $("join-screen").classList.add("hidden");$("game-ui").classList.remove("hidden");$("loading").classList.remove("hidden");
  buildResort();
  data.players.forEach(addOrUpdatePlayer);
  $("loading").classList.add("hidden");
  showChat("SYSTEM","You entered the resort. Share the room code to invite one person.");
  $("player-count").textContent=`${data.players.length} / 2`;
}
$("join-button").addEventListener("click",()=>{
  $("join-error").textContent="";
  const roomCode=$("room-code").value.trim().toUpperCase();
  const name=$("player-name").value.trim()||"Guest";
  socket.emit("join-room",{roomCode,name});
});
$("room-code").addEventListener("keydown",e=>{if(e.key==="Enter")$("join-button").click();});
socket.on("join-error",msg=>$("join-error").textContent=msg);
socket.on("joined-room",enterGame);
socket.on("player-joined",p=>{addOrUpdatePlayer(p);showChat("SYSTEM",`${p.name} joined the resort.`);});
socket.on("player-updated",p=>addOrUpdatePlayer(p));
socket.on("player-left",id=>{const p=players.get(id);removePlayer(id);if(p)showChat("SYSTEM",`${p.name} left the resort.`);});
socket.on("room-count",n=>$("player-count").textContent=`${n} / 2`);
socket.on("chat-message",m=>showChat(m.name,m.text));
window.addEventListener("keydown",e=>{
  keys[e.code]=true;
  if(e.code==="KeyE"&&!e.repeat){localAction="wave";actionUntil=performance.now()+1100;}
  if(e.code==="KeyQ"&&!e.repeat)sitting=!sitting;
});
window.addEventListener("keyup",e=>keys[e.code]=false);
$("wave-button").addEventListener("click",()=>{localAction="wave";actionUntil=performance.now()+1100;});
$("sit-button").addEventListener("click",()=>sitting=!sitting);
$("leave-button").addEventListener("click",()=>location.reload());
$("chat-form").addEventListener("submit",e=>{
  e.preventDefault();const input=$("chat-input");const value=input.value.trim();if(value){socket.emit("chat-message",value);input.value="";}
});
