const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const path = require("path");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

app.use(express.static(path.join(__dirname, "public")));

const rooms = new Map();
const MAX_PLAYERS = 2;

function cleanRoomCode(value) {
  return String(value || "").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 8);
}

io.on("connection", (socket) => {
  socket.on("join-room", ({ roomCode, name }) => {
    const code = cleanRoomCode(roomCode);
    if (!code || code.length < 4) {
      socket.emit("join-error", "Enter a room code with at least 4 characters.");
      return;
    }

    let room = rooms.get(code);
    if (!room) {
      room = new Map();
      rooms.set(code, room);
    }
    if (room.size >= MAX_PLAYERS) {
      socket.emit("join-error", "This room is full. Each room supports 2 players.");
      return;
    }

    const player = {
      id: socket.id,
      name: String(name || "Guest").slice(0, 18),
      x: room.size === 0 ? -1.4 : 1.4,
      y: 0,
      z: 2,
      rotation: 0,
      action: "idle"
    };

    socket.join(code);
    socket.data.roomCode = code;
    room.set(socket.id, player);

    socket.emit("joined-room", {
      roomCode: code,
      selfId: socket.id,
      players: [...room.values()]
    });
    socket.to(code).emit("player-joined", player);
    io.to(code).emit("room-count", room.size);
  });

  socket.on("player-update", (update) => {
    const code = socket.data.roomCode;
    if (!code || !rooms.has(code)) return;
    const room = rooms.get(code);
    const player = room.get(socket.id);
    if (!player) return;

    player.x = Number.isFinite(update.x) ? Math.max(-18, Math.min(18, update.x)) : player.x;
    player.y = Number.isFinite(update.y) ? Math.max(0, Math.min(4, update.y)) : player.y;
    player.z = Number.isFinite(update.z) ? Math.max(-18, Math.min(18, update.z)) : player.z;
    player.rotation = Number.isFinite(update.rotation) ? update.rotation : player.rotation;
    player.action = ["idle", "walk", "wave", "sit"].includes(update.action) ? update.action : "idle";
    socket.to(code).emit("player-updated", player);
  });

  socket.on("chat-message", (message) => {
    const code = socket.data.roomCode;
    if (!code || !rooms.has(code)) return;
    const player = rooms.get(code).get(socket.id);
    if (!player) return;
    const text = String(message || "").trim().slice(0, 240);
    if (text) io.to(code).emit("chat-message", { name: player.name, text, id: socket.id });
  });

  socket.on("disconnect", () => {
    const code = socket.data.roomCode;
    if (!code || !rooms.has(code)) return;
    const room = rooms.get(code);
    room.delete(socket.id);
    socket.to(code).emit("player-left", socket.id);
    io.to(code).emit("room-count", room.size);
    if (room.size === 0) rooms.delete(code);
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`TOGETHER Resort running on http://localhost:${PORT}`));
